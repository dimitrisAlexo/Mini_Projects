package com.horest.game.graphics;

import java.awt.image.BufferedImage;

//animation is one line of the player's sprite (with its direction)
public class Animation {
	
	private BufferedImage[] frames;
	//the frame we are in
	private int currentFrame;
	//the total number of frames
	private int numOfFrames;
	
	private int count;
	//time between changing frames
	private int delay;
	
	//times the animation completed
	private int timesPlayed;
	
	public Animation() {
		timesPlayed = 0;
	}
	
	public Animation(BufferedImage[] frames) {
		timesPlayed = 0;
		setFrames(frames);
	}
	
	public void setFrames(BufferedImage[] frames) {
		this.frames = frames;
		currentFrame = frames.length - 1;
		count = 0;
		timesPlayed = 0;
		delay = 2;
		numOfFrames = frames.length;
	}
	
	public void setCount(int i) { count = i; }
	public void setDelay(int i) { delay = i; }
	public void setFrame(int i) { currentFrame = i; }
	public void setNumOfFrames(int i) { numOfFrames = i; }
	
	public void update() {
		if(delay == -1) return;
		
		count++;
		if(count == delay) {
			currentFrame++;
			count = 0;
		}
		if(currentFrame == numOfFrames) {
			currentFrame = 0;
			timesPlayed++;
		}
	}
	
	public int getDelay() { return delay; }
	public int getFrame() { return currentFrame; }
	public int getCount() { return count; }
	public int getTimesPlayed() { return timesPlayed; }
	public BufferedImage getImage() { return frames[currentFrame]; }
	public boolean hasPlayedOnce() { return timesPlayed > 0; }
	public boolean hasPlayed(int i) { return timesPlayed == i; }
	
}
