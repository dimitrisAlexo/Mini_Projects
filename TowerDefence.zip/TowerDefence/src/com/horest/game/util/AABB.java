package com.horest.game.util;


//collision class
public class AABB {
	//its a collision box around entity
	private Vector2f pos;
	private float xOffset = 0;
	private float yOffset = 0;
	private float w;
	private float h;
	
	//for vision(circle area)
	private float r;
	
	//if w != h, size = the max
	//private int size;
	
	//init box
	public AABB(Vector2f pos, int w, int h) {
		this.pos = pos;
		this.w = w;
		this.h = h;
		this.r = 0;
		
		//size = Math.max(w, h);
	}
	
	//AABB circle
	public AABB(Vector2f pos, int r) {
		this.pos = pos;
		this.r = r;		
		//size = r;
	}

	public Vector2f getPos() {
		return pos;
	}

	public float getRadius() {
		return r;
	}

	public float getWidth() {
		return w;
	}

	public float getHeight() {
		return h;
	}
	
	public void setW(float w) {
		this.w = w;
	}

	public void setH(float h) {
		this.h = h;
	}

	public void setBox(Vector2f pos, int w, int h) {
		this.pos = pos;
		this.w = w;
		this.h = h;
		//size = Math.max(w, h);
	}
	
	public void setCircle(Vector2f pos, int r) {
		this.pos = pos;
		this.r = r;
		//size = r;
	}

	public void setxOffset(float xOffset) {
		this.xOffset = xOffset;
	}

	public void setyOffset(float yOffset) {
		this.yOffset = yOffset;
	}
	
	public float getxOffset() {
		return xOffset;
	}

	public float getyOffset() {
		return yOffset;
	}
	
	public void update(Vector2f pos) {
		if(r == 0) {
			this.setBox(pos, (int) this.w, (int) this.h);
		}
		else {
			this.setCircle(pos,(int) this.r);
		}
	}

	//colliding 2 entities
	public boolean collides(AABB bBox) {
		//get the coord of middle of the box
		float ax = (pos.getWorldVar().x + xOffset) + (w / 2);
		float ay = (pos.getWorldVar().y + yOffset) + (h / 2);
		
		float bx = (bBox.getPos().getWorldVar().x + bBox.xOffset) + (w / 2);
		float by = (bBox.getPos().getWorldVar().y + bBox.yOffset) + (h / 2);
		
		//if they collide
		if(Math.abs(ax - bx) < (this.w/2) + (bBox.w/2)) {
			if(Math.abs(ay - by) < (this.h/2) + (bBox.h/2)) {
				return true;
			}
		}
		return false;
	}
	
	//circle collides with a box
	public boolean colCircleBox(AABB aBox) {		
		float dx = Math.max(aBox.pos.getWorldVar().x + aBox.getxOffset(), Math.min(pos.getWorldVar().x + (r / 2), aBox.pos.getWorldVar().x + aBox.getxOffset() + aBox.getWidth()));
		float dy = Math.max(aBox.pos.getWorldVar().y + aBox.getyOffset(), Math.min(pos.getWorldVar().y + (r / 2), aBox.pos.getWorldVar().y + aBox.getyOffset() + aBox.getHeight()));
		
		dx = pos.getWorldVar().x + (r / 2) - dx;
		dy = pos.getWorldVar().y + (r / 2) - dy;
		
		if(Math.sqrt(dx * dx + dy * dy) < r / 2) {
			return true;
		}
		
		return false;
	}
	
	public boolean isIn(int x, int y) {
		if(x >= pos.x && x <= pos.x + w) {
			if(y >= pos.y && y <= pos.y + h) {
				return true;
			}
		}
		return false;
	}
	
	public boolean isInCircle(int x, int y) {
		
		float dfc = (float) Math.sqrt(Math.pow(x - (pos.x + r / 2), 2) + Math.pow(y - (pos.y + r / 2), 2));
		
		if(dfc < (r / 2)) {
			return true;
		}
		return false;
	}
}
