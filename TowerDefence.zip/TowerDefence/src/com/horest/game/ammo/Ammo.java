package com.horest.game.ammo;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.horest.game.graphics.Animation;
import com.horest.game.graphics.Sprite;
import com.horest.game.util.Vector2f;

public abstract class Ammo {
	
	protected final int SHOTED = 0;
	protected final int COLLIDED = 1;
	
	protected int currentAnimation;
	
	protected Sprite sprite;
	protected Animation ani;
	protected Vector2f pos;
	protected int size;
	
	protected float dx;
	protected float dy;
			
	protected boolean hasCollided;

	protected Ammo(Sprite sprite, Vector2f orgin, int size, float dx, float dy) {
		this.sprite = sprite;
		pos = orgin;
		this.size = size;
		
		this.dx = dx;
		this.dy = dy;
				
		ani = new Animation();
		setAnimation(SHOTED, sprite.getSpriteArray(SHOTED), 3);
				
		hasCollided = false;
	}
	
	private void setAnimation(int i, BufferedImage[] frames, int delay) {
		currentAnimation = i;
		ani.setFrames(frames);
		ani.setDelay(delay);
	}
	
	public boolean hasCollided() {
		return hasCollided;
	}
	
	public Animation getAni() {
		return ani;
	}
	
	public void setSize(int size) {
		this.size = size;
	}
	
	private void animate() {
		final int DELAY = 8;
		
		if(hasCollided) {
			if(currentAnimation != COLLIDED || ani.getDelay() == -1) {
				setAnimation(COLLIDED, sprite.getSpriteArray(COLLIDED), DELAY);
				ani.setFrame(0);
			}
		}
	}
	
	public void update() {
		animate();
		ani.update();
	}
	
	public abstract void render(Graphics2D g);

}
