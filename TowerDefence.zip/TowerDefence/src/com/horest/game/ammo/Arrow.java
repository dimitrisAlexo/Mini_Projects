package com.horest.game.ammo;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.geom.AffineTransform;

import com.horest.game.graphics.Sprite;
import com.horest.game.util.Vector2f;

public class Arrow extends Ammo{
	
	private boolean delete;
	private double angle;

	public Arrow(Sprite sprite, Vector2f orgin, int size, float dx, float dy) {
		super(sprite, orgin, size, dx, dy);
		
		delete = false;
		angle = 0;
	}
	
	public boolean readyToDelete() {
		return delete;
	}

	public void setAngle(float dx, float dy) {
		if (dx != 0) {
			double radians = Math.atan(dy / dx) + (dx < 0 ? Math.PI : 0);
			angle = Math.toDegrees(radians);
			if (angle < 0) angle += 360;
		} else {
			angle = dy > 0 ? 90 : 270;
		}
	}
	
	private void move() {
		pos.x += dx;
		pos.y += dy;		

		setAngle(dx, dy);

	}
	
	@Override
	public void update() {
		super.update();

		move();

	}

	@Override
	public void render(Graphics2D g) {
		BufferedImage img = rotateImageByDegrees(ani.getImage(), angle);
		g.drawImage(img, (int) pos.x, (int) pos.y, size, size, null);
		
		g.setColor(Color.white);
	}
	
	private BufferedImage rotateImageByDegrees(BufferedImage img, double angle) {
        double rads = Math.toRadians(angle);
        
        int w = img.getWidth();
        int h = img.getHeight();
        
        int newWidth = img.getWidth();
        int newHeight = img.getHeight();

        BufferedImage rotated = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = rotated.createGraphics();
        AffineTransform at = new AffineTransform();

        int x = w / 2;
        int y = h / 2;

        at.rotate(rads, x, y);
        g2d.setTransform(at);
        g2d.drawImage(img, 0, 0, null);
        g2d.dispose();

        return rotated;
    }

}
