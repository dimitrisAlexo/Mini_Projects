package com.horest.game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import com.horest.game.states.GameStateManager;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;

public class GamePanel extends JPanel implements Runnable {

	private static final long serialVersionUID = 1L;
	public static int width;
	public static int height;
	
	public static int oldFrameCount;
	
	private Thread thread;
	private boolean running = false;
	private BufferedImage img;
	private Graphics2D g;
	
	private MouseHandler mouse;
	private KeyHandler key;
	
	private GameStateManager gsm;

	public GamePanel(int width, int height) {
		GamePanel.width = width;
        GamePanel.height = height;
        setPreferredSize(new Dimension(width, height));
        setFocusable(true);
        requestFocus();
	}
	
	//overrides runnable function
	public void addNotify() {
		//input and mouse
		super.addNotify();
		
		//craete a thread
		if(thread == null) {
			//(target, name)
			thread = new Thread(this, "GameThread");
			//calls run()
			thread.start();
		}
	}
	
	public void init() {
		running = true;
		
		//background image
		img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		//draw the img with graphics
		g = (Graphics2D) img.createGraphics();
		
		//initialize mouse and key handler
		mouse = new MouseHandler(this);
		key = new KeyHandler(this);
		
		//initialize game state manager
		gsm = new GameStateManager();
	}
	
	//overrides runnable function (runs when the panel opens)
	public void run() {
		init();

        final double GAME_HERTZ = 64.0;
        final double TBU = 1000000000 / GAME_HERTZ; // Time Before Update

        final int MUBR = 5; // Must Update before render

        double lastUpdateTime = System.nanoTime();
        double lastRenderTime;

        final double TARGET_FPS = 60;
        final double TTBR = 1000000000 / TARGET_FPS; // Total time before render

        int frameCount = 0;
        int lastSecondTime = (int) (lastUpdateTime / 1000000000);
        oldFrameCount = 0;

        while (running) {

            double now = System.nanoTime();
            int updateCount = 0;
            while (((now - lastUpdateTime) > TBU) && (updateCount < MUBR)) {
                update();
                input(mouse, key);
                lastUpdateTime += TBU;
                updateCount++;
                // (^^^^) We use this varible for the soul purpose of displaying it
            }

            if ((now - lastUpdateTime) > TBU) {
                lastUpdateTime = now - TBU;
            }

            input(mouse, key);
            render();
            draw();
            lastRenderTime = now;
            frameCount++;

            int thisSecond = (int) (lastUpdateTime / 1000000000);
            if (thisSecond > lastSecondTime) {
                if (frameCount != oldFrameCount) {
                    System.out.println("NEW SECOND " + thisSecond + " " + frameCount);
                    oldFrameCount = frameCount;
                }

                frameCount = 0;
                lastSecondTime = thisSecond;
            }

            while (now - lastRenderTime < TTBR && now - lastUpdateTime < TBU) {
                Thread.yield();

                try {
                    Thread.sleep(1);
                } catch (Exception e) {
                    System.out.println("ERROR: yielding thread");
                }

                now = System.nanoTime();
            }

        }
	}
	
	public void update() {
		//update game state manager
		gsm.update();
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		gsm.input(mouse, key);
	}
	
	//render the image
	public void render() {
		if(g != null) {
			//color of background (r, g, b)
			g.setColor(Color.cyan);
			//(x, y, width, height) from the top left corner
			g.fillRect(0, 0, width, height);
			
			gsm.render(g);
		}
	}
	
	//draws the image
	public void draw() {
		//calling jpanel graphics
		Graphics g2 = (Graphics) this.getGraphics();
		//(image, x, y, width, height, observer)
		g2.drawImage(img, 0, 0, width, height, null);
		g2.dispose();
	}
}
