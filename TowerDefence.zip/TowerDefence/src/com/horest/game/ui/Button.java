package com.horest.game.ui;

import java.awt.Graphics2D;

import com.horest.game.graphics.Sprite;
import com.horest.game.util.AABB;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class Button {
	
	private String text;
	private Vector2f pos;
	private AABB bounds;
	
	private boolean clicked;
	private boolean hovering;
	
	//private int width;
	//private int height;
	
	private int lettersWidth;
	private int lettersHeight;

	public Button(String text, Vector2f pos, int width, int height) {
		this.text = text;
		this.pos= pos;
		
		bounds = new AABB(pos, width, height);
		
		lettersWidth = width / text.length();
		lettersHeight = height;
		
		clicked = false;
		hovering = false;
	}
	
	public boolean isClicked() {
		return clicked;
	}
	
	public void update() {
		
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {	
		if(!clicked) {
			if(bounds.isIn(mouse.getX(), mouse.getY())) {
				hovering = true;
				
				if(mouse.getButton() == 1) {
					clicked = true;	
				}
			}
			else {
				hovering = false;
			}
		}
	}

	public void render(Graphics2D g) {
		if(hovering) {
			Sprite.drawArray(g, text, new Vector2f(pos.x - 3 * (text.length() / 2), pos.y - 3), lettersWidth + 3, lettersHeight + 3, lettersWidth + 3);
		}
		else {
			Sprite.drawArray(g, text, pos, lettersWidth, lettersHeight, lettersWidth);
		}
		
	}
}
