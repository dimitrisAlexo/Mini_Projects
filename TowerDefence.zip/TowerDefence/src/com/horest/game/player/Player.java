package com.horest.game.player;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.horest.game.GamePanel;
import com.horest.game.graphics.Sprite;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class Player {
	
	private int coins;
	private int hearts;
	
	private BufferedImage coinImg;
	private BufferedImage heartImg;

	public Player(int coins, int hearts) {
		this.coins = coins;
		this.hearts = hearts;
		
		coinImg = loadImage("player/Coin.png");
		heartImg = loadImage("player/Heart.png");
	}

	public int getCoins() {
		return coins;
	}

	public void setCoins(int coins) {
		this.coins = coins;
	}
	
	public void addCoins(int coins) {
		this.coins += coins;
	}

	public int getHearts() {
		return hearts;
	}

	public void setHearts(int hearts) {
		this.hearts = hearts;
	}
	
	public void removeHeart() {
		hearts--;
	}
	
	public void update() {

	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		
	}
	
	public void render(Graphics2D g) {
		g.drawImage(coinImg, GamePanel.width / 2 - 80, 30, 32, 32, null);
		
		Sprite.drawArray(g, String.valueOf(coins), new Vector2f(GamePanel.width / 2 - 48, 30), 32, 24);
		
		for(int i=0;i<hearts;i++) {
			g.drawImage(heartImg, GamePanel.width / 2 + 80 + i * 32, 30, 32, 32, null);
		}
	}
	
	
	private BufferedImage loadImage(String file) {
		BufferedImage img = null;
		try {
			System.out.println("Loading: " + file + "...");
			img = ImageIO.read(getClass().getClassLoader().getResourceAsStream(file));
		}catch(Exception e){
			System.out.println("ERROR could not load file: " + file);
		}
		return img;
	}
	
}
