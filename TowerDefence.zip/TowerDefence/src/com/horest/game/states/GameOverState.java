package com.horest.game.states;

import java.awt.Graphics2D;

import com.horest.game.GamePanel;
import com.horest.game.graphics.Sprite;
import com.horest.game.ui.Button;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class GameOverState extends GameState {
	
	private Button playAgainBtn;
	private Button exitBtn;

	public GameOverState(GameStateManager gsm) {
		super(gsm);
		
		playAgainBtn = new Button("PLAY AGAIN", new Vector2f(GamePanel.width / 2 - 4.5f * 48, GamePanel.height / 2 - 24), 48 * 10, 48);
		exitBtn = new Button("EXIT", new Vector2f(GamePanel.width / 2 - 1.5f * 48, GamePanel.height / 2 - 24 + 100), 48 * 4, 48);
	}

	@Override
	public void update() {
		if(playAgainBtn.isClicked()) {
			gsm.pop(GameStateManager.PLAY);
			gsm.add(GameStateManager.PLAY);
			gsm.pop(GameStateManager.GAMEOVER);
		}
		else if(exitBtn.isClicked()) {
			gsm.pop(GameStateManager.PLAY);
			gsm.pop(GameStateManager.GAMEOVER);
			gsm.add(GameStateManager.MENU);
		}
	}

	@Override
	public void input(MouseHandler mouse, KeyHandler key) {
		playAgainBtn.input(mouse, key);
		exitBtn.input(mouse, key);
	}

	@Override
	public void render(Graphics2D g) {
		Sprite.drawArray(g, "YOU WON", new Vector2f(GamePanel.width / 2 - 3 * 64, GamePanel.height / 2 - 32 - 132), 64, 64);
		playAgainBtn.render(g);
		exitBtn.render(g);
	}

}
