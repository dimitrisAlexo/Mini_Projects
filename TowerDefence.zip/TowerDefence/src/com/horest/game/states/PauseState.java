package com.horest.game.states;

import java.awt.Graphics2D;

import com.horest.game.GamePanel;
import com.horest.game.graphics.Sprite;
import com.horest.game.ui.Button;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class PauseState extends GameState {
	
	private Button resumeBtn;
	private Button exitBtn;

	public PauseState(GameStateManager gsm) {
		super(gsm);
		
		resumeBtn = new Button("RESUME", new Vector2f(GamePanel.width / 2 - 2.5f * 48, GamePanel.height / 2 - 24), 48 * 6, 48);
		exitBtn = new Button("EXIT", new Vector2f(GamePanel.width / 2 - 1.5f * 48, GamePanel.height / 2 - 24 + 100), 48 * 4, 48);
	}

	@Override
	public void update() {
		if(resumeBtn.isClicked()) {
			gsm.pop(GameStateManager.PAUSE);
		}
		else if(exitBtn.isClicked()) {
			System.exit(0);
		}
	}

	@Override
	public void input(MouseHandler mouse, KeyHandler key) {
		resumeBtn.input(mouse, key);
		exitBtn.input(mouse, key);
	}

	@Override
	public void render(Graphics2D g) {
		Sprite.drawArray(g, "GAME PAUSED", new Vector2f(GamePanel.width / 2 - 5 * 64, GamePanel.height / 2 - 32 - 132), 64, 64);
		resumeBtn.render(g);
		exitBtn.render(g);
	}

}
