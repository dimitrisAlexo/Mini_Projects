package com.horest.game.states;

import java.awt.Graphics2D;

import com.horest.game.GamePanel;
import com.horest.game.graphics.Sprite;
import com.horest.game.map.Map;
import com.horest.game.map.Map1;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class PlayState extends GameState{
	
	private Map map;
	
	public PlayState(GameStateManager gsm) {
		super(gsm);
		
		map = new Map1("map/Map1.png");
	}

	@Override
	public void update() {		
		map.update();
		
		if(map.getOutcome() != 0) {
			map = new Map1("map/Map1.png");
		}
	}

	@Override
	public void input(MouseHandler mouse, KeyHandler key) {
		map.input(mouse, key);
	}

	//render on screen the current game state
	@Override
	public void render(Graphics2D g) {
		map.render(g);
				
		Sprite.drawArray(g, GamePanel.oldFrameCount + " FPS", new Vector2f(GamePanel.width - 192, 32), 32, 24);
	}

}
