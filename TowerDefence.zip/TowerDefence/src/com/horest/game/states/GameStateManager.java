package com.horest.game.states;
import java.awt.Graphics2D;

import com.horest.game.GamePanel;
import com.horest.game.graphics.Font;
import com.horest.game.graphics.Sprite;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class GameStateManager {
	
	private GameState states[];
	
	//the map of the game taking all the panel
	public static Vector2f map;
	
	//indexes of the states
	public static final int PLAY = 0;
	public static final int MENU = 1;
	public static final int PAUSE = 2;
	public static final int GAMEOVER = 3;
	
	public int onTopState = 0;
	
	public static Font font;
	
	public GameStateManager() {
		map = new Vector2f(GamePanel.width, GamePanel.height);
		//position of player in our world (we are moving the scene not the player)
		Vector2f.setWorldVar(map.x, map.y);
		
		states = new GameState[4];
		
		font = new Font("font/font1.png", 10, 10);
		Sprite.currentFont = font;
		
		states[PLAY] = new PlayState(this);
		//states[MENU] = new MenuState(this);
	}
	
	public boolean getState(int state) {
		return states[state] != null;
	}
	
	//reomve a specific state
	public void pop(int state) {
		states[state] = null;
	}
	
	public void add(int state) {
		if(states[state] != null) {
			return;
		}
		if(state == PLAY) {
			states[PLAY] = new PlayState(this);
		}
		if(state == MENU) {
			states[MENU] = new MenuState(this);
		}
		if(state == PAUSE) {
			states[PAUSE] = new PauseState(this);
		}
		if(state == GAMEOVER) {
			states[GAMEOVER] = new GameOverState(this);
		}
	}
	
	public void addAndPop(int state) {
		addAndPop(state, 0);
	}
	
	public void addAndPop(int state, int remove) {
		addAndPop(state, 0);
		pop(state);
		add(state);
	}
	
	public void update() {
		for(int i=0;i<states.length;i++) {
			if(states[i] != null) {
				states[i].update();
			}
		}
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		for(int i=0;i<states.length;i++) {
			if(states[i] != null) {
				states[i].input(mouse, key);
			}
		}
	}
	
	public void render(Graphics2D g) {
		for(int i=0;i<states.length;i++) {
			if(states[i] != null) {
				states[i].render(g);
			}
		}
	}

}
