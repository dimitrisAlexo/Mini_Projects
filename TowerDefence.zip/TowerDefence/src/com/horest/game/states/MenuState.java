package com.horest.game.states;

import java.awt.Graphics2D;

import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;

public class MenuState extends GameState {
	
	public MenuState(GameStateManager gsm) {
		super(gsm);
	}

	@Override
	public void update() {

	}

	@Override
	public void input(MouseHandler mouse, KeyHandler key) {

	}

	@Override
	public void render(Graphics2D g) {
		
	}

}
