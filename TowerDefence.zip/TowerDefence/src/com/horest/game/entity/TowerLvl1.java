package com.horest.game.entity;

import java.awt.Graphics2D;
import java.util.ArrayList;

import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class TowerLvl1 extends Tower{

    public TowerLvl1(String path, Vector2f pos){
		super(path, pos);
    }

    public void update(ArrayList<Enemy> enemies) {
		
		archer.update(enemies);

	}

	public void render(Graphics2D g) {

		g.drawImage(img, (int)(archer.getPos().x - 25), (int)(archer.getPos().y + 20), 80, 140, null);
		archer.render(g);

	}

	@Override
	public void input(MouseHandler mouse, KeyHandler key) {
		
	}    
}
