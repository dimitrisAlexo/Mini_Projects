package com.horest.game.entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.horest.game.graphics.Animation;
import com.horest.game.graphics.Sprite;
import com.horest.game.util.AABB;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

//anything that can move in the game
public abstract class Entity {
	
	//directions of animation (the row of the sprite)
	//private final int UP = -1; //we dont use other animation for up
	//private final int DOWN = -1; //we dont use other animation for down
	protected final int LEFT = 1;
	protected final int RIGHT = 0;
	protected final int JUMPR = 2;
	protected final int JUMPL = 3;
	
	//up, down, left, right
	protected int currentAnimation;
	
	protected Sprite sprite;
	//the cuurent animation according to the directions
	protected Animation ani;
	protected Vector2f pos;
	protected int size;
	
	//movement
	protected boolean up;
	protected boolean down;
	protected boolean right;
	protected boolean left;
	
	//attacking the enemy
	protected boolean attack;
	protected boolean interact;
	protected boolean jump;
	
	public boolean xCol;
	public boolean yCol;
	
	protected int attackSpeed;
	protected int attackDuration;
	
	//speed moving
	protected float dx;
	protected float dy;
	
	protected float maxSpeed;
	protected float acc;//acceleration
	protected float deacc; //deacceleration
	
	//AABB
	protected AABB hitBounds;
	protected AABB bounds;
	
	
	public Entity(Sprite sprite, Vector2f orgin, int size) {
		this.sprite = sprite;
		pos = orgin;
		this.size = size;
		
		bounds = new AABB(orgin, size, size);
		//init hit box to the right(half the size righter)
		hitBounds = new AABB(new Vector2f(orgin.x + (size / 2), orgin.y), size, size);
		
		ani = new Animation();
		//set default animation to looking right
		setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), 1);
	}
	
	public Vector2f getPos() { return pos; }
	public void setSprite(Sprite sprite) { this.sprite = sprite; }
	public void setSize(int i) { size = i; }
	public void setMaxSpeed(float f) { maxSpeed = f; }
	public float getMaxSpeed() { return maxSpeed; } 
	public void setAcc(float f) { acc = f; }
	public void setDeacc(float f) { deacc = f; }
	public float getDeacc() { return deacc; }
	
	public float getDx() { return dx; }
	public float getDy() { return dy; } 
	
	public AABB getBounds() { return bounds; }
	public AABB getHitBounds() { return hitBounds; }
	public int getSize() { return size; }
	public Animation getAnimation() { return ani; }
	
	public boolean getJump() {
		return jump;
	}
	
	public void setAnimation(int i, BufferedImage[] frames, int delay) {
		currentAnimation = i;
		ani.setFrames(frames);
		ani.setDelay(delay);
	}
		
	//KEEP ONLY LEFT & RIGHT
	public void animate() {
		final int DELAY = 5;
		final int JUMPDELAY = 7;
		//get the right direction to animate
		
		if(jump) {
			if(left) {
				if(currentAnimation != JUMPL || ani.getDelay() == -1) {
					setAnimation(JUMPL, sprite.getSpriteArray(JUMPL), JUMPDELAY);
					ani.setFrame(0);
					ani.setNumOfFrames(5);
				}
			}
			else if(right) {
				if(currentAnimation != JUMPR || ani.getDelay() == -1) {
					setAnimation(JUMPR, sprite.getSpriteArray(JUMPR), JUMPDELAY);
					ani.setFrame(0);
					ani.setNumOfFrames(5);
				}
			}
			else {
				if(currentAnimation == RIGHT) {
					if(currentAnimation != JUMPR || ani.getDelay() == -1) {
						setAnimation(JUMPR, sprite.getSpriteArray(JUMPR), JUMPDELAY);
						ani.setFrame(0);
						ani.setNumOfFrames(5);
					}
				}
				else if(currentAnimation == LEFT) {
					if(currentAnimation != JUMPL || ani.getDelay() == -1) {
						setAnimation(JUMPL, sprite.getSpriteArray(JUMPL), JUMPDELAY);
						ani.setFrame(0);
						ani.setNumOfFrames(5);
					}
				}
			}
		}
		else {
			if(up) {
				if(ani.getDelay() == -1) {
					setAnimation(currentAnimation, sprite.getSpriteArray(currentAnimation), DELAY);
				}
				if(right || currentAnimation == JUMPR) {
					if(currentAnimation != RIGHT || ani.getDelay() == -1) {
						setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), DELAY);
					}
				}
				else if(left || currentAnimation == JUMPL) {
					if(currentAnimation != LEFT || ani.getDelay() == -1) {
						setAnimation(LEFT, sprite.getSpriteArray(LEFT), DELAY);
					}
				}
			}
			else if(down) {
				if(ani.getDelay() == -1) {
					setAnimation(currentAnimation, sprite.getSpriteArray(currentAnimation), DELAY);
				}
				if(right || currentAnimation == JUMPR) {
					if(currentAnimation != RIGHT || ani.getDelay() == -1) {
						setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), DELAY);
					}
				}
				else if(left || currentAnimation == JUMPL) {
					if(currentAnimation != LEFT || ani.getDelay() == -1) {
						setAnimation(LEFT, sprite.getSpriteArray(LEFT), DELAY);
					}
				}
			}
			else if(right) {
				if(currentAnimation != RIGHT || ani.getDelay() == -1) {
					setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), DELAY);
				}
			}
			else if(left) {
				if(currentAnimation != LEFT || ani.getDelay() == -1) {
					setAnimation(LEFT, sprite.getSpriteArray(LEFT), DELAY);
				}
			}
			else {
				if(currentAnimation == JUMPR) {
					currentAnimation = RIGHT;
				}
				else if(currentAnimation == JUMPL) {
					currentAnimation = LEFT;
				}
				//to stop the animation
				setAnimation(currentAnimation, sprite.getSpriteArray(currentAnimation), -1);
			}
		}
		
	}
	
	private void setHitBoxDirection() {
		//default = right
		if(up) {
			//bring it up and left
			hitBounds.setyOffset(-size / 2);
			hitBounds.setxOffset(-size / 2);
		}
		else if(down) {
			//bring it down and left
			hitBounds.setyOffset(size / 2);
			hitBounds.setxOffset(-size / 2);
		}
		else if(right) {
			hitBounds.setxOffset(0);
			hitBounds.setyOffset(0);
		}
		else if(left) {
			hitBounds.setxOffset(-size);
			hitBounds.setyOffset(0);
		}
	}
	
	public void update() {
		animate();
		bounds.update(pos);
		hitBounds.update(new Vector2f(pos.x + (size / 2), pos.y));
		setHitBoxDirection(); //in which direction the player can hit
		ani.update();
	}
	
	public abstract void render(Graphics2D g, AABB cam);
	public void input(MouseHandler mouse, KeyHandler key) {
		
	}
}
