package com.horest.game.entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.horest.game.util.AABB;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class Enemy {
	
	private BufferedImage img;
	
	private Vector2f pos;
	private int size;
	
	//speed moving
	private float dx;
	private float dy;

	public Enemy(Vector2f pos, int size, String file) {
		this.pos = pos;
		this.size = size;
		
		img = loadImage(file);
	}
	
	public Vector2f getPos() {
		return pos;
	}

	public void setPos(Vector2f pos) {
		this.pos = pos;
	}

	public void update(float dx, float dy) {
		pos.x += dx;
		pos.y += dy;
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		
	}
	
	public void render(Graphics2D g) {
		if(pos.x >= -size) {
			g.drawImage(img, (int) pos.x, (int) pos.y, size, size, null);
		}
	}
	
	
	private BufferedImage loadImage(String file) {
		BufferedImage img = null;
		try {
			System.out.println("Loading: " + file + "...");
			img = ImageIO.read(getClass().getClassLoader().getResourceAsStream(file));
		}catch(Exception e){
			System.out.println("ERROR could not load file: " + file);
		}
		return img;
	}
}
