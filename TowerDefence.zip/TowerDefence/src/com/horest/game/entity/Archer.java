package com.horest.game.entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import com.horest.game.ammo.Arrow;
import com.horest.game.graphics.Animation;
import com.horest.game.graphics.Sprite;
import com.horest.game.util.Vector2f;

public class Archer {
	
	protected Sprite sprite;
	protected Animation ani;
	protected Vector2f pos;
	protected Vector2f dir = new Vector2f(0, 0);
	protected int size;
	
	protected final int FIRING = 0;

	private boolean flag = true;
	
	protected int currentAnimation;
	
	protected ArrayList<Arrow> arrow;
	protected Enemy enemy;

	protected Archer(Sprite sprite, Vector2f origin, int size) {
		this.sprite = sprite;
		pos = origin;
		this.size = size;

		ani = new Animation();
		setAnimation(FIRING, sprite.getSpriteArray(FIRING), -1);
		ani.setFrame(3);
		
		arrow = new ArrayList<Arrow>();
	}
	
	public Vector2f getPos() {
		return pos;
	}

	protected void setAnimation(int i, BufferedImage[] frames, int delay) {
		currentAnimation = i;
		ani.setFrames(frames);
		ani.setDelay(delay);
	}
	
	protected void animate() {
		final int FIREDELAY = 10;

		if(ani.getDelay() == -1) {
			setAnimation(FIRING, sprite.getSpriteArray(FIRING), FIREDELAY);
		}

	}
	
	protected float distance(Vector2f pos, Enemy enemy){
		return (float)Math.sqrt(Math.pow((pos.x - enemy.getPos().x), 2) + Math.pow((pos.y - enemy.getPos().y), 2));
	}

	protected void chooseTarget(ArrayList<Enemy> enemies){

		if(enemies.get(0) != null){
			enemy = enemies.get(0);
			for(int i = 0; i < enemies.size(); i++){
				if(distance(pos, enemies.get(i)) < distance(pos, enemy)){
					enemy = enemies.get(i);
				}
			}
		}
		else{
			System.out.println("Enemy out of bounds.");
		}
	}

	protected Vector2f dirToShoot(ArrayList<Enemy> enemies) {
		chooseTarget(enemies);

		dir.x = Math.abs(pos.x - enemy.getPos().x) / (distance(pos, enemy) / 15);
		dir.y = Math.abs(pos.y - enemy.getPos().y) / (distance(pos, enemy) / 15);

		dir.y = (enemy.getPos().y < pos.y) ? -dir.y : dir.y;
		dir.x = (enemy.getPos().x < pos.x) ? -dir.x : dir.x;

		return dir;
	}
	
	public void update(ArrayList<Enemy> enemies) {
		animate();
		ani.update();
		
		if(currentAnimation == FIRING) {
			if(ani.getFrame() == 0 && flag) {
				dir = dirToShoot(enemies);
				arrow.add(new Arrow(new Sprite("ammo/arrow.png", 50, 100), new Vector2f(pos.x, pos.y), 32, dir.x, dir.y));
				flag = false;
			}
			if(ani.getFrame() == 1) flag = true;
		}

		for(int i = 0; i < arrow.size(); i++) {

			if(arrow.get(i).hasCollided() && arrow.get(i).readyToDelete()) {
				arrow.remove(i);
			}
			else {
				arrow.get(i).update();
			}
		}
	}

	public void render(Graphics2D g) {

		g.drawImage(ani.getImage(), (int) pos.x, (int) pos.y, size, size, null);

		for(int i=0;i<arrow.size();i++) {
			arrow.get(i).render(g);
		}

	}
}
