package com.horest.game.entity;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;

import com.horest.game.graphics.Sprite;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public abstract class Tower {

    protected BufferedImage img;

    protected Archer archer;
    
    protected int value;

    protected Tower(String path, Vector2f pos){
		img = loadImage(path);
		archer = new Archer(new Sprite("tower/archer.png", 101, 92), pos, 50);
		
		value = 30;
    }

    public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public abstract void update(ArrayList<Enemy> enemies);
    
    public abstract void input(MouseHandler mouse, KeyHandler key);

	public abstract void render(Graphics2D g);

    private BufferedImage loadImage(String file) {
		BufferedImage image = null;
		try {
			image = ImageIO.read(getClass().getClassLoader().getResourceAsStream(file));
		}catch(Exception e){
			System.out.println("ERROR could not load file: " + file);
		}
		return image;
	}
    
}
