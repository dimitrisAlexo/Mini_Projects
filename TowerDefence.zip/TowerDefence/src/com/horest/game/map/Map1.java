package com.horest.game.map;

import java.util.ArrayList;

import com.horest.game.GamePanel;
import com.horest.game.entity.Enemy;
import com.horest.game.entity.Tower;
import com.horest.game.player.Player;
import com.horest.game.util.Vector2f;

public class Map1 extends Map{
	
	private final int PLAYERCOINS = 100;
	private final int PLAYERHEARTS = 3;
	
	private Vector2f towerPositions[] = {new Vector2f(120, 310), new Vector2f(570, 150), new Vector2f(730, 620), new Vector2f(1050, 230)};

	public Map1(String file) {
		super(file);
		numOfTowers = towerPositions.length;
		numOfEnemies = 7;
		
		numOfTroops = 3;
		troopsCounter = 1;
		
		towerPlaces = new TowerPlace[numOfTowers];
		
		for(int i=0;i<numOfTowers;i++) {
			towerPlaces[i] = new TowerPlace(towerPositions[i], "tower/TowerPlace.png");
		}
		
		towers = new Tower[numOfTowers];
		
		player = new Player(PLAYERCOINS, PLAYERHEARTS);

		enemies = new ArrayList<Enemy>();
		
		for(int i=0;i<numOfEnemies;i++) {
			enemies.add(new Enemy(new Vector2f((float) (0 - Math.random() * 80 * numOfEnemies), (float) (GamePanel.height / 2 + Math.random() * 40)), 32, "tower/TowerPlace.png"));
		}
	}
	
	public void update() {
		super.moveEnemies();
		
		if(enemies.size() == 0) {
			if(troopsCounter == 1) {
				numOfEnemies = 10;
				player.addCoins(20);
			}
		}
		
		super.update();
	}

	@Override
	public Vector2f giveDirections(float x, float y, float offset) {
		float dx = 0;
		float dy = 0;
		
		float maxSpeed = 1f;
		
		if(x < 230 + offset) {
			dx = maxSpeed;
			dy = 0;
		}
		else if(x < 240 && y > (200 + offset)) {
			dx = 0;
			dy = -maxSpeed;
		}
		else if(x < 480 + offset) {
			dx = maxSpeed;
			dy = 0;
		}
		else if(x < 490 && y < (490 + offset)) {
			dx = 0;
			dy = maxSpeed;
		}
		else if(x < 830 + offset) {
			dx = maxSpeed;
			dy = 0;
		}
		else if(y > (340 + offset)) {
			dx = 0;
			dy = -maxSpeed;
		}
		else {
			dx = maxSpeed;
			dy = 0;
		}

		return new Vector2f(dx, dy);
	}

}
