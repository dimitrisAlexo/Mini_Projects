package com.horest.game.map;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import com.horest.game.GamePanel;
import com.horest.game.entity.Enemy;
import com.horest.game.entity.Tower;
import com.horest.game.entity.TowerLvl1;
import com.horest.game.graphics.Sprite;
import com.horest.game.player.Player;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public abstract class Map {
	
	protected BufferedImage map;
	
	protected int numOfTowers;
	protected TowerPlace towerPlaces[];
	protected Tower towers[];
	
	protected Player player;
	
	protected ArrayList<Enemy> enemies;
	protected int numOfEnemies;
	
	protected int numOfTroops;
	protected int troopsCounter;
	
	protected int outcome; // 0 = playing, 1 = won, 2 = lost

	public Map(String file) {
		map = loadMap(file);
	}
	
	public int getOutcome() {
		return outcome;
	}
	
	protected void moveEnemies() {
		//moves enemies
		for(int i=0;i<enemies.size();i++) {
			Vector2f dir = giveDirections(enemies.get(i).getPos().x, enemies.get(i).getPos().y, (float) (Math.random() * i - 40));
			enemies.get(i).update(dir.x, dir.y);
					
			//if enemy passed the map
			if(enemies.get(i).getPos().x > GamePanel.width) {
				enemies.remove(i);
				//player.removeHeart();
				i--;
			}
		}
	}

	public void update() {
		if(player.getHearts() > 0) {
		
			//build towers
			for(int i=0;i<numOfTowers;i++) {
				if(towerPlaces[i] != null) {
					towerPlaces[i].update();
					
					if(towerPlaces[i].isBuilt()) {
						towers[i] = new TowerLvl1("tower/tower.png", new Vector2f(towerPlaces[i].getPos().x - TowerPlace.r / 2, towerPlaces[i].getPos().y - TowerPlace.r * 3));
						
						//check if tower can be build
						if(towers[i].getValue() <= player.getCoins()) {
							System.out.println("Tower built!");
							
							towerPlaces[i] = null;
							
							player.addCoins(-towers[i].getValue());
						}
						else {
							towers[i] = null;
							towerPlaces[i].setBuilt(false);
						}
					}
				}
				if(towers[i] != null) {
					towers[i].update(enemies);
				}
			}
			
			//update enemies
			if(enemies.size() == 0) {
				if(troopsCounter != numOfTroops) {
					for(int i=0;i<numOfEnemies;i++) {
						enemies.add(new Enemy(new Vector2f((float) (0 - Math.random() * 80 * numOfEnemies), (float) (GamePanel.height / 2 + Math.random() * 40)), 32, "tower/TowerPlace.png"));
					}
					
					troopsCounter++;
				}
				else {
					outcome = 1;
				}
			}
		}
		else {
			outcome = 2;
		}
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		if(player.getHearts() > 0) {
			for(int i=0;i<numOfTowers;i++) {
				
				if(towerPlaces[i] != null) {
					towerPlaces[i].input(mouse, key);
				}
				
				if(towers[i] != null) {
					towers[i].input(mouse, key);
				}
			}
		}
	}

	public void render(Graphics2D g) {
		g.drawImage(map, 0, 0, GamePanel.width, GamePanel.height, null);
		
		for(int i=0;i<numOfTowers;i++) {
			if(towerPlaces[i] != null) {
				towerPlaces[i].render(g);
			}
			
			if(towers[i] != null) {
				towers[i].render(g);
			}
		}

		for(int i=0;i<enemies.size();i++) {
			enemies.get(i).render(g);
		}
		
		player.render(g);
		Sprite.drawArray(g, "RAID:" + troopsCounter + "/" + numOfTroops, new Vector2f(30, 30), 32, 24);
	}
	
	public abstract Vector2f giveDirections(float x, float y, float offset);

	private BufferedImage loadMap(String file) {
		BufferedImage img = null;
		try {
			System.out.println("Loading: " + file + "...");
			img = ImageIO.read(getClass().getClassLoader().getResourceAsStream(file));
		}catch(Exception e){
			System.out.println("ERROR could not load file: " + file);
		}
		return img;
	}

}
