package com.horest.game.map;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.horest.game.util.AABB;
import com.horest.game.util.KeyHandler;
import com.horest.game.util.MouseHandler;
import com.horest.game.util.Vector2f;

public class TowerPlace {

	private Vector2f pos;
	private BufferedImage img;
	private BufferedImage hammerImg;
	
	public static final int r = 40;
	private AABB bounds;
	
	private boolean isBuilt;
	private boolean hovering;

	public TowerPlace(Vector2f pos, String file) {
		this.pos = pos;
		
		bounds = new AABB(new Vector2f(pos.x - r, pos.y - r), 2 * r);
		img = loadImage(file);
		hammerImg = loadImage("tower/Hammer.png");
		
		isBuilt = false;
		hovering = false;
	}
	
	public boolean isBuilt() {
		return isBuilt;
	}

	public void setBuilt(boolean isBuilt) {
		this.isBuilt = isBuilt;
	}

	public int getR() {
		return r;
	}

	public Vector2f getPos() {
		return pos;
	}

	public void setPos(Vector2f pos) {
		this.pos = pos;
	}

	public void update() {
		
	}
	
	public void input(MouseHandler mouse, KeyHandler key) {
		if(bounds.isInCircle(mouse.getX(), mouse.getY()) && !isBuilt) {
			hovering = true;
			
			if(mouse.getButton() == 1) {
				isBuilt = true;
			}
		}
		else {
			hovering = false;
		}
	}
	
	public void render(Graphics2D g) {
		//g.setColor(Color.red);
		g.drawImage(img, (int) pos.x - r, (int) pos.y - r, 2 * r, 2 * r, null);
		
		if(hovering) {
			g.setColor(Color.yellow);
			g.drawOval((int) (pos.x - r), (int) (pos.y - r), 2 * r, 2 * r);
			
			g.drawImage(hammerImg, (int) pos.x - r / 2, (int) pos.y - r / 2, r, r, null);
		}
	}
	
	private BufferedImage loadImage(String file) {
		BufferedImage img = null;
		try {
			System.out.println("Loading: " + file + "...");
			img = ImageIO.read(getClass().getClassLoader().getResourceAsStream(file));
		}catch(Exception e){
			System.out.println("ERROR could not load file: " + file);
		}
		return img;
	}

}
