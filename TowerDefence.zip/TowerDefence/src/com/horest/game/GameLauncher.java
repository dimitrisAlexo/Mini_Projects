package com.horest.game;

public class GameLauncher {
	
	public GameLauncher() {
		new Window();
	}

	public static void main(String[] args) {
		new GameLauncher();
	}
}
