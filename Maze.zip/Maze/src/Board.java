package src;

//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)

public class Board {

    int N; // οι διαστάσεις του ταμπλό N x N
    int S; // ο αριθμός των εφοδίων που υπάρχουν στο ταμπλό
    int W; // ο αριθμός των τειχών που μπορείτε να προσθέσετε στο λαβύρινθο
    Tile[] tiles; // ένας πίνακας με αντικείμενα τύπου Tile. Τα ids παίρνουν τιμές από το 0 έως το NxN - 1
    Supply[] supplies; // ένας πίνακας με αντικείμενα τύπου Supply

    public Board(){     // κενός constructor
        N = 0;
        S = 0;
        W = 0;
        tiles = new Tile[N * N];
        for(int i = 0; i < N * N; i ++){
            tiles[i] = new Tile();
        }

        supplies = new Supply[S];
        for(int i = 0; i < S; i++){
            supplies[i] = new Supply();
        }
    }

    public Board(int N, int S, int W){      // constructor με ορίσματα
        this.N = N;
        this.S = S;
        this.W = W;
        tiles = new Tile[N * N];
        for(int i = 0; i < N * N; i ++){
            tiles[i] = new Tile();
        }
        supplies = new Supply[S];
        for(int i = 0; i < S; i++){
            supplies[i] = new Supply();
        }
    }

    public Board(Board board){          // constructor με όρισμα αντικείμενο τύπου Board
        
        Board clone = new Board(board.N, board.S, board.W);
        N = clone.N;
        S = clone.S;
        W = clone.W;

        tiles = new Tile[N * N];
        supplies = new Supply[S];

        for(int i = 0; i < N * N; i++){
            tiles[i] = new Tile(board.tiles[i]);
        }

        for(int i = 0; i < S; i++){
            supplies[i] = new Supply(board.supplies[i]);
        }

    }


    // ακολουθούν setters και getters της κλάσης Board
    public void setN(int N){
        this.N = N;
    }

    public int getN(){
        return N;
    }

    public void setS(int S){
        this.S = S;
    }

    public int getS(){
        return S;
    }

    public void setW(int W){
        this.W = W;
    }

    public int getW(){
        return W;
    }
    // τέλος setters και getters

    public int getNumberOfWallsForTile(Tile tile){      // μέθοδος που παίρνει ως όρισμα ένα αντικείμενο τύπου Tile και επιστρέφει τον αριθμό των τειχών που αυτό περιέχει
        int count = 0; // μετρητής
        if(tile.getUp()) count++;
        if(tile.getDown()) count++;
        if(tile.getLeft()) count++;
        if(tile.getRight()) count++;
        return count;
    }

    public void createTile (int N, int W, Tile[] tiles){        // μέθοδος που αρχικοποιεί τον πίνακα tiles[]
        int count = 0; // μετρητής για να μην ξεπεράσει τον αριθμό των walls W
        for(int i = 0; i < (N * N); i++){        // set Id, X and Y
            tiles[i].setTileId(i);
            tiles[i].setX(tiles[i].getTileId() / N);
            tiles[i].setY(tiles[i].getTileId() % N);
            tiles[i].setSupply(false);
        }

        for(int i = 0; i < (N * N); i++){
            if(tiles[i].getX() == 0){                           // side tiles
                tiles[i].setDown(true);
                count++;
            }
            if(tiles[i].getY() == 0){
                tiles[i].setLeft(true);
                count++;
            }
            if(tiles[i].getX() == (N - 1)){
                tiles[i].setUp(true);
                count++;
            }
            if(tiles[i].getY() == (N - 1)){
                tiles[i].setRight(true);
                count++;
            }
        }
        
        while(count <= W){

            int random = ((int)(Math.random()*10000)) % (N * N); // το id ενός τυχαίου tile
            if(getNumberOfWallsForTile(tiles[random]) < 2){
                count++;
                int rand = ((int)(Math.random()*100)) % 4;
                switch (rand) {
                    case 0: if(!tiles[random].getUp() && getNumberOfWallsForTile(tiles[random + N]) < 2){
                                tiles[random].setUp(true);
                                break;
                            } 
                    case 1: if(!tiles[random].getDown() && getNumberOfWallsForTile(tiles[random - N]) < 2){
                                tiles[random].setDown(true);
                                break;
                            } 
                    case 2: if(!tiles[random].getLeft() && getNumberOfWallsForTile(tiles[random - 1]) < 2){
                                tiles[random].setLeft(true);
                                break;
                            }
                    case 3: if(!tiles[random].getRight() && getNumberOfWallsForTile(tiles[random + 1]) < 2){
                                tiles[random].setRight(true);
                                break;
                            }
                    default: break;
                }
            }

            if(tiles[random].getY() != 0 && tiles[random].getLeft()){       // neighboring tiles
                tiles[random - 1].setRight(true);
            }

            if(tiles[random].getY() != (N - 1) && tiles[random].getRight()){
                tiles[random + 1].setLeft(true);
            }

            if(tiles[random].getX() != 0 && tiles[random].getDown()){
                tiles[random - N].setUp(true);
            }

            if(tiles[random].getX() != (N - 1) && tiles[random].getUp()){
                tiles[random + N].setDown(true);
            }
        }
    }

    public void createSupply(int N, int S, Tile[] tiles, Supply[] supplies){         // μέθοδος που αρχικοποιεί τον πίνακα supplies[]
        for(int i = 0; i < S; i++){
            supplies[i].setSupplyId(i);
        }
        for(int i = 0; i < S; i++){
            boolean flag = false; // έλεγχος για το αν έχει μπει supply στο συγκεκριμένο tile
            while(!flag){
                int random = ((int)(Math.random()*10000)) % (N * N);
                if(random != 0 && random != ((N * N) / 2) && !tiles[random].getSupply()){
                    supplies[i].setSupplyTileId(tiles[random].getTileId());
                    supplies[i].setX(tiles[random].getX());
                    supplies[i].setY(tiles[random].getY());
                    tiles[random].setSupply(true);
                    flag = true;
                }
            }
        }
    }

    public void createBoard(){          // μέθοδος που κατασκευάζει τον πίνακα μέσω των δύο προηγούμενων μεθόδων
        createTile(this.N, this.W, this.tiles);
        createSupply(this.N, this.S, this.tiles, this.supplies);
    }

    public String[][] getStringRepresentation(int theseusTile, int minotaurTile, Game game){    // μέθοδος που επιστρέφει σε String την γραφική απεικόνιση του λαβυρίνθου στην κατάσταση που βρίσκεται κάθε φορά

        String[][] toString = new String[2 * N + 1][N]; // ο πίνακας που θα επιστρέφεται

        for(int i = 0; i < 2 * N + 1; i++){                         // initialization
            for(int j = 0; j < N; j++){
                toString[i][j] = "        ";
            }
        }

        for(int i = 0; i < N; i++){                                 // upper border
            toString[0][i] = "+ - - - ";
            if(i == N - 1) toString[0][i] += "+";
        }

        for(int i = 0; i < N; i++){                                 // lower border
            if(i == 0 && game.getRound() == 0){
                toString[2 * N][i] = "+       ";
            }
            else toString[2 * N][i] = "+ - - - ";
            if(i == N - 1) toString[2 * N][i] += "+";
        }

        for(int i = 2, k = N; i < 2 * N; i+=2, k+=N){
            for(int j = 0; j < N; j++){
                if(tiles[N * N - k  + j].getDown()){
                    toString[i][j] = "+ - - - ";
                }
                else toString[i][j] = "+       ";
                if(j == N - 1) toString[i][j] += "+";
            }
        }
        for(int i = 1, k = N; i < 2 * N + 1; i+=2, k+=N){
            for(int j = 0; j < N; j++){
                if(j == 0){
                    toString[i][j] = "|       ";
                }
                if(tiles[N * N - k  + j].getLeft()) toString[i][j] = "|       ";
                if(j == N - 1){
                    toString[i][j] += "|";
                }
            }
        }
        {
            int x = tiles[theseusTile].getX(); // οι συντεταγμένες του κάθε κελιού σε καρτεσιανό σύστημα
            int y = tiles[theseusTile].getY();
            int i = 2 * (N - x) - 1; // οι συντεταγμένες του κάθε κελιού στον πίνακα toString[][]
            int j = y;
            String temp; // προσωρινό String στο οποίο γίνεται η επιθυμητή αντικατάσταση και το οποίο στη συνέχεια εισάγουμε στο toString[][]
            if(tiles[theseusTile].getLeft()){
                if(theseusTile == minotaurTile) temp = toString[i][j].replace("       ", "   M   ");
                else temp = toString[i][j].replace("       ", "   T   ");
            } 
            else{
                if(theseusTile == minotaurTile) temp = toString[i][j].replace("        ", "    M   ");
                else temp = toString[i][j].replace("        ", "    T   ");
            } 
            toString[i][j] = temp;
        }
        {
            int x = tiles[minotaurTile].getX();
            int y = tiles[minotaurTile].getY();
            int i = 2 * (N - x) - 1;
            int j = y;
            String temp; // ομοίως με το παραπάνω String temp
            if(tiles[minotaurTile].getLeft()) temp = toString[i][j].replace("       ", "   M   ");
            else temp = toString[i][j].replace("        ", "    M   ");
            toString[i][j] = temp;
        }
        for(int k = 0; k < S; k++){
            if(supplies[k].getSupplyTileId() == 0) continue;
            int x = supplies[k].getX();
            int y = supplies[k].getY();
            int i = 2 * (N - x) - 1;
            int j = y;
            String temp; // ομοίως με το παραπάνω String temp
            
            if(tiles[supplies[k].getSupplyTileId()].getLeft()){
                if(minotaurTile == supplies[k].getSupplyTileId()){
                    temp = toString[i][j].replace("   M   ", " S" + (supplies[k].getSupplyId() + 1) + " + M");
                }
                else temp = toString[i][j].replace("       ", "  S" + (supplies[k].getSupplyId() + 1) + "   ");
            }
            else{
                if(minotaurTile == supplies[k].getSupplyTileId()){
                    temp = toString[i][j].replace("    M   ", " S" + (supplies[k].getSupplyId() + 1) + " + M ");
                }
                else temp = toString[i][j].replace("        ", "   S" + (supplies[k].getSupplyId() + 1) + "   ");
            }
            toString[i][j] = temp;
        }
        
        return toString;
    }

}
