package src;

import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class Graphics implements ActionListener {

    int width;
    int height;
    int x;
    int y;

    int rows;
    int cols;
    int turn;
    boolean play;
    boolean playAgain;

    BoardPanel boardPanel;

    JPanel scorePanel = new JPanel();
    JPanel endPanel = new JPanel(); //for the end panel
    JPanel endTextPanel = new JPanel(); //helping panel

    JLabel score = new JLabel();
    
    JLabel label = new JLabel();
    JLabel labelT = new JLabel("THESEUS");
    JLabel labelM = new JLabel("MINOTAUR");
    JLabel labelChooseT = new JLabel("Choose Your Player:");
    JLabel labelChooseM = new JLabel("Choose Your Opponent:");
    JLabel endLabel = new JLabel();

    JFrame frame = new JFrame();
    JFrame endframe = new JFrame();

    JButton playbutton;
    JButton quitbutton;
    JButton endquitbutton;
    JButton resetbutton;

    JComboBox comboBoxTheseus;
    int selectedIndexTheseus;

    JComboBox comboBoxMinotaur;
    int selectedIndexMinotaur;

    public Graphics(Board board, int width, int height, int x, int y, int rows, int cols, int theseusX, int theseusY,
            int minotaurX, int minotaurY) {
        this.cols = cols;
        this.rows = rows;
        this.play = false;
        this.playAgain = true;

        playbutton = new JButton("PLAY");
        playbutton.setBounds(310, 615, 100, 40);
        playbutton.addActionListener(this);
        playbutton.setFocusable(false);
        playbutton.setVerticalTextPosition(JButton.CENTER);
        playbutton.setFont(new Font("Monospaced", Font.BOLD, 25));
        playbutton.setForeground(Color.LIGHT_GRAY);
        playbutton.setBackground(Color.BLACK);

        quitbutton = new JButton("QUIT");
        quitbutton.setBounds(650, 615, 100, 40);
        quitbutton.addActionListener(this);
        quitbutton.setFocusable(false);
        quitbutton.setVerticalTextPosition(JButton.CENTER);
        quitbutton.setFont(new Font("Monospaced", Font.BOLD, 25));
        quitbutton.setForeground(Color.LIGHT_GRAY);
        quitbutton.setBackground(Color.BLACK);

        String[] optionsTheseus = { "MinMax", "Heuristic", "Random" };
        String[] optionsMinotaur = { "Heuristic", "Random" };

        comboBoxTheseus = new JComboBox(optionsTheseus);
        comboBoxMinotaur = new JComboBox(optionsMinotaur);

        comboBoxTheseus.setSelectedIndex(0);
        comboBoxMinotaur.setSelectedIndex(0);

        comboBoxTheseus.addActionListener(this);
        comboBoxMinotaur.addActionListener(this);

        comboBoxTheseus.setBounds(50, 190, 150, 45);
        comboBoxTheseus.setFocusable(false);
        comboBoxTheseus.setFont(new Font("Monospaced", Font.BOLD, 22));

        Color color = new Color(70, 75, 172);
        comboBoxTheseus.setForeground(Color.BLACK);
        comboBoxTheseus.setBackground(color);

        comboBoxMinotaur.setBounds(863, 190, 150, 45);
        comboBoxMinotaur.setFocusable(false);
        comboBoxMinotaur.setFont(new Font("Monospaced", Font.BOLD, 20));

        comboBoxMinotaur.setForeground(Color.BLACK);
        comboBoxMinotaur.setBackground(color);

        labelChooseM.setBounds(864, 150, 200, 50);
        labelChooseM.setForeground(Color.BLACK);
        labelChooseM.setFont(new Font("SansSerif", Font.BOLD, 12));

        labelChooseT.setBounds(51, 150, 200, 50);
        labelChooseT.setForeground(Color.BLACK);
        labelChooseT.setFont(new Font("SansSerif", Font.BOLD, 12));

        labelM.setBounds(878, 15, 150, 50);
        labelM.setForeground(Color.BLACK);
        labelM.setFont(new Font("Monospaced", Font.BOLD, 25));
        
        labelT.setBounds(72, 15, 150, 50);
        labelT.setForeground(Color.BLACK);
        labelT.setFont(new Font("Monospaced", Font.BOLD, 25));


        

        frame.setTitle("Theseus and Minotaur");
        frame.setSize(width, height);
        frame.setLocation(x, y);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        boardPanel = new BoardPanel(board, theseusX, theseusY, minotaurX, minotaurY);
        
        score.setForeground(Color.BLACK);
        score.setFont(new Font("SansSerif", Font.BOLD, 15));
        
        scorePanel.setBounds(478, 620, 100, 100);
        scorePanel.add(score);


        label.setForeground(Color.BLACK);
        boardPanel.add(label);
        frame.add(labelM);
        frame.add(labelT);
        frame.add(labelChooseM);
        frame.add(labelChooseT);
        frame.add(playbutton);
        frame.add(quitbutton);
        frame.add(comboBoxTheseus);
        frame.add(comboBoxMinotaur);
        frame.add(scorePanel);
        frame.add(boardPanel);
        

    }

    public void setPlay(boolean play) {
        this.play = play;
    }

    public boolean getPlay(){
        return play;
    }

    public void setPlayAgain(boolean playAgain) {
        this.playAgain = playAgain;
    }

    public boolean getPlayAgain() {
        return playAgain;
    }

    public int getTurn() {
        return turn;
    }

    public void setSelectedIndexTheseus(int selectedIndexTheseus) {
        this.selectedIndexTheseus = selectedIndexTheseus;
    }

    public int getSelectedIndexTheseus() {
        return selectedIndexTheseus;
    }

    public void setSelectedIndexMinotaur(int selectedIndexMinotaur) {
        this.selectedIndexMinotaur = selectedIndexMinotaur;
    }

    public int getSelectedIndexMinotaur() {
        return selectedIndexMinotaur;
    }

    public void finalFrame(int winnerId){

        endframe.setTitle("Game Outcome");
        endframe.setSize(480, 480);
        endframe.setLocation(500, 200);

        endframe.setVisible(true);
        endframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        endframe.setResizable(false);

        endPanel.setBounds(85, 100, 300, 100);

        endTextPanel.setBounds(0, 0, 100, 100);

        endquitbutton = new JButton("QUIT");
        endquitbutton.setBounds(120, 200, 85, 30);
        endquitbutton.addActionListener(this);
        endquitbutton.setFocusable(false);
        endquitbutton.setVerticalTextPosition(JButton.CENTER);
        endquitbutton.setFont(new Font("Monospaced", Font.BOLD, 16));
        endquitbutton.setForeground(Color.LIGHT_GRAY);
        endquitbutton.setBackground(Color.BLACK);

        resetbutton = new JButton("RESET");
        resetbutton.setBounds(264, 200, 85, 30);
        resetbutton.addActionListener(this);
        resetbutton.setFocusable(false);
        resetbutton.setVerticalTextPosition(JButton.CENTER);
        resetbutton.setFont(new Font("Monospaced", Font.BOLD, 16));
        resetbutton.setForeground(Color.LIGHT_GRAY);
        resetbutton.setBackground(Color.BLACK);

        switch (winnerId) {
            case 1:
                endLabel.setText("Congrats! Theseus won the game.");
                break;
            case 2:
                endLabel.setText("Oh no! The Minotaur won.");
                break;
            default:
                endLabel.setText("Game took way too long! It's a tie.");
                break;
        }
        
        endLabel.setForeground(Color.BLACK);
        endLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        
        endPanel.add(endLabel);
        endframe.add(endPanel);
        endframe.add(endquitbutton);
        endframe.add(resetbutton);

        endframe.add(endTextPanel);
    }

    public void updateFrame(int tX, int tY, String text, String textScore, Board board, int mX, int mY) {

        boardPanel.setTheseusX(tX);
        boardPanel.setTheseusY(tY);

        boardPanel.setMinotaurX(mX);
        boardPanel.setMinotaurY(mY);

        boardPanel.setBoard(board);
        label.setText(text);
        score.setText(textScore);

        frame.validate();
        frame.repaint();

    }

    public class BoardPanel extends JPanel {

        private static final long serialVersionUID = 1L;

        Board board;
        int theseusX;
        int theseusY;

        int minotaurX;
        int minotaurY;

        static final int originX = 252;
        static final int originY = 35;
        static final int cellSide = 37;

        public BoardPanel(Board board, int theseusX, int theseusY, int minotaurX, int minotaurY) {
            this.board = board;
            this.theseusX = theseusX;
            this.theseusY = theseusY;
            this.minotaurX = minotaurX;
            this.minotaurY = minotaurY;
        }

        public Board getBoard() {
            return board;
        }

        public void setBoard(Board board) {
            this.board = board;
        }

        public void setTheseusX(int theseusX) {
            this.theseusX = theseusX;
        }

        public void setTheseusY(int theseusY) {
            this.theseusY = theseusY;
        }

        public void setMinotaurX(int minotaurX) {
            this.minotaurX = minotaurX;
        }

        public void setMinotaurY(int minotaurY) {
            this.minotaurY = minotaurY;
        }

        @Override
        protected void paintComponent(java.awt.Graphics g) {
            super.paintComponent(g);

            Color color = new Color(224, 180, 100, 100);
            g.setColor(color);
            g.fillRect(originX, originY, cols * cellSide, rows * cellSide);
            g.setColor(Color.BLACK);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(1));

            for (int i = 0; i < rows + 1; i++) {
                for (int j = 0; j < cols; j++) {
                    if (i != rows) {
                        if (board.tiles[(cols - 1 - i) * cols + j].getUp())
                            g2.setStroke(new BasicStroke(5));
                    } else
                        g2.setStroke(new BasicStroke(5));
                    g.drawLine(originX + j * cellSide, originY + cellSide * i, originX + (j + 1) * cellSide,
                            originY + cellSide * i);
                    g2.setStroke(new BasicStroke(1));
                }
            }

            for (int i = 0; i < cols + 1; i++) {
                for (int j = 0; j < rows; j++) {
                    if (i != cols) {
                        if (board.tiles[(cols - 1 - j) * cols + i].getLeft())
                            g2.setStroke(new BasicStroke(5));
                    } else
                        g2.setStroke(new BasicStroke(5));
                    g.drawLine(originX + i * cellSide, originY + cellSide * j, originX + i * cellSide,
                            originY + cellSide * (j + 1));
                    g2.setStroke(new BasicStroke(1));
                }
            }

            if(label.getText() == "Game Started | Round 0"){
                g2.setStroke(new BasicStroke(5));
                g.setColor(Color.WHITE);
                g.drawLine(originX, originY + cols * cellSide, originX + cellSide, originY + cols * cellSide);
                
                Color basicFrame = new Color(238,238,238,255);
                g.setColor(basicFrame);
                g.drawLine(originX, originY + cols * cellSide, originX + cellSide, originY + cols * cellSide);
                
                g.setColor(color);
                g.drawLine(originX, originY + cols * cellSide, originX + cellSide, originY + cols * cellSide);
                
            }

            drawSupplies(g2);
            drawTheseus(g2);
            drawMinotaur(g2);

        }

        public Image getSupplyImage() {
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File("images/supplyPurple.png"));
            } catch (IOException ex) {
                System.out.print("dwse bonus +1 please <3");
            }

            Image newImage = image.getScaledInstance(31, 31, Image.SCALE_AREA_AVERAGING);
            return newImage;
        }

        public void drawSupplies(Graphics2D g2d) {
            for (int i = 0; i < board.getS(); i++) {
                if (board.supplies[i].getSupplyTileId() != 0) {

                    int imgx = originX + board.supplies[i].getY() * cellSide;
                    int imgy = originY + (cols - 1 - board.supplies[i].getX()) * cellSide;

                    g2d.drawImage(getSupplyImage(), imgx + 3, imgy + 4, null);

                }
            }
        }

        public Image getTheseusImage() {
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File("images/Theseus.png"));
            } catch (IOException ex) {
                System.out.print("dwse bonus +1 please <3");
            }

            Image newImage = image.getScaledInstance(31, 31, Image.SCALE_AREA_AVERAGING);
            return newImage;
        }

        public void drawTheseus(Graphics2D g2d) {
            int imgx = originX + theseusY * cellSide;
            int imgy = originY + (cols - 1 - theseusX) * cellSide;
            g2d.drawImage(getTheseusImage(), imgx + 3, imgy + 4, null);
        }

        public Image getMinotaurImage() {
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File("images/Minotaur.png"));
            } catch (IOException ex) {
                System.out.print("dwse bonus +1 please <3");
            }

            Image newImage = image.getScaledInstance(31, 31, Image.SCALE_AREA_AVERAGING);
            return newImage;
        }

        public void drawMinotaur(Graphics2D g2d) {
            int imgx = originX + minotaurY * cellSide;
            int imgy = originY + (cols - 1 - minotaurX) * cellSide;
            g2d.drawImage(getMinotaurImage(), imgx + 3, imgy + 4, null);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == playbutton){
            setPlay(true);
            this.turn = (int)((Math.random()*100) % 2);
            playbutton.setForeground(Color.BLACK);
            playbutton.setBackground(Color.LIGHT_GRAY);
            playbutton.setEnabled(false);
            
            comboBoxTheseus.setBackground(Color.WHITE);
            comboBoxTheseus.setEnabled(false);

            comboBoxMinotaur.setBackground(Color.WHITE);
            comboBoxMinotaur.setEnabled(false);
        }

        if(e.getSource() == quitbutton){
            frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        }

        if(e.getSource() == comboBoxTheseus){
            setSelectedIndexTheseus(comboBoxTheseus.getSelectedIndex());
        }

        if(e.getSource() == comboBoxMinotaur){
            setSelectedIndexMinotaur(comboBoxMinotaur.getSelectedIndex());
        }

        if(e.getSource() == endquitbutton){
            frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        }

        if(e.getSource() == resetbutton){
            setPlayAgain(false);
            frame.dispose();
            endframe.dispose();
        }

    }

}