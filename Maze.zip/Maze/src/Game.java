package src;

//Αλεξόπουλος Δημήτριος (ΑΕΜ 10091 – aadimitri@ece.auth.gr - 6987262113)
//Κότσιφα Αγγελική (ΑΕΜ 10060 – akotsifa@ece.auth.gr - 6972453627)
//Μανώλης Δημήτριος (ΑΕΜ 10104 – dmanolis@ece.auth.gr - 6947441722)

import java.util.concurrent.TimeUnit;

public class Game {
    int round; // ο τρέχον γύρος του παιχνιδιού

    public Game(){ // κενός constructor
        round = 0;
    }
    public Game(int round){ // constructor με ορίσματα
        this.round = round;
    }

    // setters και getters
    public int getRound(){
        return round;
    }
    public void setRound(int round){
        this.round = round;
    }
    // τέλος setters και getters

    public static void main(String[] args) throws InterruptedException { // η main μέθοδος του παιχνιδιού
        while(true){
            int N = 15; // μέγεθος του πίνακα
            int S = 4; // αριθμός εφοδίων
            int W = (N * N * 3 + 1) / 2; // μέγιστος αριθμός τοιχών
            int n = 50; // αριθμός γύρων

            Game game = new Game(); // αντικείμενο τύπου Game
            Board board = new Board(N, S, W); // αντικείμενο τύπου Board
            board.createBoard();

            Graphics graphics = new Graphics(board, 1080, 720, 225, 75, N, N, 0, 0, N/2, N/2);
            
            String text = "Game Started | Round 0";
            String textScore = "Score: 0";
            graphics.updateFrame(0, 0, text, textScore, board, N/2, N/2);

            MinMaxPlayer TheseusMinMax = new MinMaxPlayer(7, 1, "Theseus", 0, 0, 0, board);
            HeuristicPlayerTheseus TheseusHeuristic = new HeuristicPlayerTheseus(1, "Theseus", 0, 0, 0, board);
            Player TheseusRandom = new Player(1, "Theseus", 0, 0, 0, board);

            
            HeuristicPlayer MinotaurHeuristic = new HeuristicPlayer(2, "Minotaur", 0, N / 2, N / 2, board);
            HeuristicPlayer MinotaurRandom = new HeuristicPlayer(2, "Minotaur", 0, N / 2, N / 2, board);



            boolean winner = false; // μεταβλητή για τον έλεγχο ύπαρξης νικητή
            int winnerId = 0; // 1 = Θησέας, 2 = Μινώταυρος

            int[] arrT = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 1
            int[] arrM = new int[4]; // πίνακας που θα επιστραφεί απο την μέθοδο move() του Player 2
            arrM[0] = (N * N / 2);
            arrM[1] = N/2;
            arrM[2] = N/2;
            arrT[0] = 0;
            int diceM = 0;

            while(true){
                TimeUnit.MILLISECONDS.sleep(1);
                while(game.getRound() < (2 * n) && !winner && graphics.getPlay()){
                    if(game.getRound() % 2 == graphics.getTurn()){
                        int diceT;
                        switch (graphics.getSelectedIndexTheseus()) {
                            case 0:
                                if(graphics.getSelectedIndexMinotaur() == 0){
                                    diceT = TheseusMinMax.getNextMove(arrT[0], board, arrM, MinotaurHeuristic, TheseusMinMax);
                                }
                                else{
                                    diceT = TheseusMinMax.getNextMove(arrT[0], board, arrM, MinotaurRandom, TheseusMinMax);
                                } 

                                arrT = TheseusMinMax.move((TheseusMinMax.getX()*N)+TheseusMinMax.getY(), diceT, board);
                                
                                break;
                            
                            case 1:
                                diceT = TheseusHeuristic.getNextMove(arrT[0], game.getRound(), arrM);
                                arrT = TheseusHeuristic.move((TheseusHeuristic.getX()*N)+TheseusHeuristic.getY(), diceT, board);
                                break;
                            
                            case 2:
                                int temp = (int)((Math.random()*100) % 4);
                                diceT = 2 * temp + 1;
                                arrT = TheseusRandom.move((TheseusRandom.getX()*N)+TheseusRandom.getY(), diceT, board);
                                break;
                            
                        
                            default:
                                if(graphics.getSelectedIndexMinotaur() == 0){
                                    diceT = TheseusMinMax.getNextMove(arrT[0], board, arrM, MinotaurHeuristic, TheseusMinMax);
                                }
                                else{
                                    diceT = TheseusMinMax.getNextMove(arrT[0], board, arrM, MinotaurRandom, TheseusMinMax);
                                } 
                                arrT = TheseusMinMax.move((TheseusMinMax.getX()*N)+TheseusMinMax.getY(), diceT, board);
                                break;
                        }
                    }
                    
                    else{

                        switch (graphics.getSelectedIndexMinotaur()) {
                            case 0:
                                diceM = MinotaurHeuristic.getNextMove(arrM[0], arrT, board);
                                arrM = MinotaurHeuristic.move((MinotaurHeuristic.getX()*N)+MinotaurHeuristic.getY(), diceM, board);
                                break;
                            
                            case 1:
                                int temp = (int)((Math.random()*100) % 4);
                                diceM = 2 * temp + 1;
                                arrM = MinotaurRandom.move((MinotaurRandom.getX()*N)+MinotaurRandom.getY(), diceM, board);
                                break;
                            
                            default:
                                diceM = MinotaurHeuristic.getNextMove(arrM[0], arrT, board);
                                arrM = MinotaurHeuristic.move((MinotaurHeuristic.getX()*N)+MinotaurHeuristic.getY(), diceM, board);
                                break;
                        }
                    }
                    if(arrT[0] == arrM[0]){
                        winner = true;
                        winnerId = 2;
                    }

                    switch (graphics.getSelectedIndexTheseus()) {
                        case 0:
                            if(TheseusMinMax.getScore() == S){
                                winner = !winner;
                                winnerId = 1;
                            } 
                            break;
                        case 1:
                            if(TheseusHeuristic.getScore() == S){
                                winner = !winner;
                                winnerId = 1;
                            } 
                            break;
                        case 2:
                            if(TheseusRandom.getScore() == S){
                                winner = !winner;
                                winnerId = 1;
                            } 
                            break;
                        default:
                            break;
                    }
                    
                    game.setRound(game.getRound() + 1);

                    String newText = "Round: " + game.getRound();
                    String newTextScore;
                    switch (graphics.getSelectedIndexTheseus()) {
                        case 0:
                            newTextScore = "Score: " + TheseusMinMax.getScore();
                            break;
                        case 1:
                            newTextScore = "Score: " + TheseusHeuristic.getScore();
                            break;
                        case 2:
                            newTextScore = "Score: " + TheseusRandom.getScore();
                            break;
                        default:
                            newTextScore = "Default";
                            break;
                    } 
                    graphics.updateFrame(arrT[1], arrT[2], newText, newTextScore, board, arrM[1], arrM[2]);
                    
                    TimeUnit.MILLISECONDS.sleep(250);
                    
                }
                if(graphics.getPlay()){
                    graphics.finalFrame(winnerId);
                    break;
                }
            }
            while(graphics.getPlayAgain()){
                try {
                    TimeUnit.MILLISECONDS.sleep(200);
                } catch (InterruptedException e) {
                    System.out.println("Time Exception!");
                }
            }
        }
    }    
}
