#include "TestColorSquare.h"

#include "Renderer.h"
#include "imgui/imgui.h"

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

namespace test {

    TestColorSquare::TestColorSquare()
        : r(0.0f), g(0.0f), b(0.0f), a(0.0f)
	{
        float positions[] = {
            -0.5f, -0.5f, // 0
             0.5f, -0.5f, // 1
             0.5f,  0.5f, // 2
            -0.5f,  0.5f  // 3
        };

        unsigned int indices[] = {
            0, 1, 2,
            2, 3, 0
        };

        GLCall(glEnable(GL_BLEND));
        GLCall(glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA));

        m_VAO = std::make_unique<VertexArray>();

        m_VertexBuffer = std::make_unique<VertexBuffer>(positions, 4 * 2 * sizeof(float));
        VertexBufferLayout layout;
        layout.Push<float>(2);
        m_VAO->AddBuffer(*m_VertexBuffer, layout);

        m_IndexBuffer = std::make_unique<IndexBuffer>(indices, 6);

        m_Shader = std::make_unique<Shader>("res/shaders/BasicSquare.shader");
        m_Shader->Bind();
        m_Shader->SetUniform4f("u_Color", 0.8f, 0.3f, 0.8f, 1.0f);
	}

    TestColorSquare::~TestColorSquare()
	{
	}

	void TestColorSquare::OnUpdate(float deltaTime)
	{
	}

	void TestColorSquare::OnRender()
	{
        Renderer renderer;

        m_Shader->Bind();
        m_Shader->SetUniform4f("u_Color", r, g, b, a);

        renderer.Draw(*m_VAO, *m_IndexBuffer, *m_Shader);
	}

	void TestColorSquare::OnImGuiRender()
	{
        ImGui::SliderFloat("Red", &r, 0.0f, 1.0f);
        ImGui::SliderFloat("Green", &g, 0.0f, 1.0f);
        ImGui::SliderFloat("Blue", &b, 0.0f, 1.0f);
        ImGui::SliderFloat("Alpha", &a, 0.0f, 1.0f);
        ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
	}

}